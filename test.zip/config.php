<?php
	define('V_SELF', '');
	define('V_VIRTC','Virtc');
	define('V_TABLE_PREF','');
	define('V_MODELS_PATCH','Virtc_Bd_Models_');


?>