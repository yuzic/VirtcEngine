<?
 return array('host' =>'127.0.0.1',
					'login'=>'',
					'pass' => '',
					'port' =>6379,
					'db'   => 'virtc',
					'key_preffix' => 'katalog_',
					'debug'=> true,
);
					