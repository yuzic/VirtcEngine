<?
 return array('host' =>'localhost',
					'login'=>'root',
					'pass' => '123456',
					'dbname'   => 'search',
					'debug'=> true,
);
					