<?
 return array('db' =>'mysqli',
                'adapterDb'	 =>'Mysqli',
                'adapterCache'=>'Redis',
                'shema'		 => 'Mysqli',
                'translator' => 'TMysqli',

);
	