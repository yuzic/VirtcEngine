<?php
/**
 * @desc класс загрузки ORM
 */
class Virtc{
	    
	public static function Run(){
		require_once "Virtc/Bootstrap.php";
		BootStrap::Run();
	}

}

?>
