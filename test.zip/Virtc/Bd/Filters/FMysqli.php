<?
	/**
	* @desc собраны фильтры для mysqls 
	*/
	class FMysql
	{
		public function distinct($field){
			
		}	


	}