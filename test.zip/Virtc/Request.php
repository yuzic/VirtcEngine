<?
	class Request{
		public  static function getPost($name){
			return $_POST[$name];
		}
	}
	